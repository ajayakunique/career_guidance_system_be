from fastapi import FastAPI, UploadFile, File, HTTPException
import mysql.connector
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from typing import List
import requests
import json
import re
import io
import PyPDF2

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
def sql():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="career_guidance",
        port=3306)

#USERS LOGIN
class User(BaseModel):
    Email: str
    Password: str
@app.post("/login")
def login(data: User):
    mydb = sql()
    try:
        cursor = mydb.cursor(dictionary=True)
        cursor.execute(
            "SELECT * FROM new_account WHERE Email=%s AND Password=%s",
            (data.Email, data.Password)
        )
        user = cursor.fetchone()
        cursor.close()
        if not user:
            return {"message": "Invalid email or password"}
        return {
            "message": "Login successful",
            "user": {
                "name": user["Full_Name"],
                "email": user["Email"]
            }
        }
    finally:
        mydb.close()

# FORGET PASSWORD
class Forget_password(BaseModel):
    Email: str
@app.post("/forget-password")
def forget_password(data: Forget_password):
    mydb = sql()
    try:
        cursor = mydb.cursor(dictionary=True)
        cursor.execute("SELECT * FROM new_account WHERE Email=%s", (data.Email,))
        user = cursor.fetchone()
        cursor.close()
        if not user:
            return {"message": "Email not found"}
        return {"message": "Email verified"}
    finally:
        mydb.close()

#RESET PASSWORD
class ResetPassword(BaseModel):
    Email: str
    Password: str
@app.post("/reset-password")
def reset_password(data: ResetPassword):
    mydb = sql()
    try:
        cursor = mydb.cursor(dictionary=True)
        update_query = "UPDATE new_account SET Password=%s WHERE Email=%s"
        cursor.execute(update_query, (data.Password, data.Email))
        mydb.commit()
        cursor.close()
        return {"message": "Password reset successful"}
    finally:
        mydb.close()

#CREATE ACCOUNT
class create_account(BaseModel):
    Full_Name: str
    Email: str
    Password: str
    Degree:str
    Skills:str
    Interests:str
@app.post("/create_new_account")
def create_new_account(data: create_account):
    mydb = sql()
    try:
        mypost = mydb.cursor(dictionary=True)
        mypost.execute(
            """INSERT INTO new_account 
            (Full_Name, Email, Password, Degree, Skills, Interests) 
            VALUES (%s, %s, %s, %s, %s, %s)""",
            (
                data.Full_Name,
                data.Email,
                data.Password,
                data.Degree,
                data.Skills,
                data.Interests
            )
        )
        mydb.commit()
        mypost.close()
        return {"message": "Account Created"}
    finally:
        mydb.close()

#DASHBOARD
class Account(BaseModel):
    Email: str
@app.post("/dashboard")
def dashboard(data: Account):
    mydb = sql()
    cursor = mydb.cursor(dictionary=True)
    query = """
    SELECT Degree AS Your_Degree, Skills, Interests
    FROM new_account 
    WHERE Email=%s
    """
    cursor.execute(query, (data.Email,))
    result = cursor.fetchall()
    mydb.close()
    return {"show": result}

#ANSWERS DATA
class AnswerItem(BaseModel):
    question_id: int
    answer: str
class AnswerData(BaseModel):
    email: str
    answers: List[AnswerItem]
@app.get("/question")
def get_questions():
    db = sql()
    try:
        cursor = db.cursor(dictionary=True)
        cursor.execute("""
            SELECT q.id, q.question, o.option 
            FROM questions q 
            JOIN options o ON q.id = o.question_id 
            ORDER BY q.id
        """)
        rows = cursor.fetchall()
        questions = {}
        for row in rows:
            qid = row["id"]
            if qid not in questions:
                questions[qid] = {
                    "id": qid,
                    "question": row["question"],
                    "options": []
                }
            questions[qid]["options"].append(row["option"])
        cursor.close()
        return list(questions.values())
    finally:
        db.close()
@app.post("/save-answers")
def save_answers(data: dict):
    print("RECEIVED:", data)
    db = sql()
    cursor = db.cursor(dictionary=True)
    email = data.get("email")
    answers = data.get("answers", [])
    cursor.execute(
        "SELECT Id FROM new_account WHERE Email=%s",
        (email,)
    )
    user = cursor.fetchone()
    if not user:
        print("User not found")
        return {"message": "User not found"}
    user_id = user["Id"]
    print("USER ID:", user_id)
    cursor.execute(
        "DELETE FROM student_answers WHERE student_id=%s",
        (user_id,)
    )
    for ans in answers:
        qid = ans.get("question_id")
        answer = ans.get("answer")
        print("INSERTING:", user_id, qid, answer)
        cursor.execute(
            """
            INSERT INTO student_answers 
            (student_id, question_id, selected_option)
            VALUES (%s, %s, %s)
            """,
            (user_id, qid, answer)
        )
    db.commit()
    db.close()
    print("DATA INSERTED")
    return {"message": "Answers saved successfully"}

#RESULT
class CareerRequest(BaseModel):
    Email: str
@app.post("/career-recommendation")
def career_recommendation(data: CareerRequest):
    mydb = sql()
    mypost = mydb.cursor(dictionary=True)
    mypost.execute(
        "SELECT id, Skills, Interests FROM new_account WHERE Email=%s",
        (data.Email,)
    )
    student = mypost.fetchone()
    if not student:
        return {"error": "Student not found"}
    student_id = student["id"]
    skills = student["Skills"]
    interests = student["Interests"]
    mypost.execute(
        "SELECT selected_option FROM student_answers WHERE student_id=%s",
        (student_id,)
    )
    answers = mypost.fetchall()
    if not answers:
        return {
            "status": "pending",
            "message": "Please complete assessment first"
        }
    answer_list = [row["selected_option"] for row in answers]
    answers_text = ", ".join(answer_list)
    prompt = f"""
Student Skills: {skills}
Student Interests: {interests}
Student Question Answers:
{answers_text}
Based on this student profile suggest the TOP 3 career matches.
Return ONLY JSON in this format:
{{
 "careers":[
  {{
   "rank":1,
   "job_title":"Software Developer",
   "match_percentage":92,
   "required_skills":["JavaScript","React","Node.js","Git","Problem Solving"]
  }},
  {{
   "rank":2,
   "job_title":"Data Scientist",
   "match_percentage":85,
   "required_skills":["Python","Machine Learning","Statistics","SQL","Data Visualization"]
  }},
  {{
   "rank":3,
   "job_title":"Backend Developer",
   "match_percentage":80,
   "required_skills":["Python","Django","SQL","API Development"]
  }}
 ]
}}
Return only JSON. No explanation.
"""
    try:
        response = requests.post(
            "http://localhost:11434/api/generate",
            json={
                "model": "gemma3:1b",
                "prompt": prompt,
                "stream": False
            },
            timeout=120
        )
        ai_text = response.json().get("response", "")
        print("RAW AI:", ai_text)
        import re
        try:
            json_text = re.search(r'\{.*\}', ai_text, re.DOTALL).group()
            ai_result = json.loads(json_text)
        except:
            ai_result = {"careers": []}
    except Exception as e:
        ai_result = {"error": str(e)}
    mypost.execute(
        "DELETE FROM career_recommendations WHERE student_id=%s",
        (student_id,)
    )
    mydb.commit()
    for career in ai_result.get("careers", []):
        mypost.execute(
            """INSERT INTO career_recommendations 
            (student_id, job_title, match_percentage, required_skills)
            VALUES (%s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                match_percentage = VALUES(match_percentage),
                required_skills = VALUES(required_skills)
            """,
            (
                student_id,
                career.get("job_title"),
                career.get("match_percentage"),
                ", ".join(career.get("required_skills", []))
            )
        )
    mydb.commit()
    return {
        "student_id": student_id,
        "skills": skills,
        "interests": interests,
        "answers": answer_list,
        "career_matches": ai_result.get("careers", [])
    }

#SKILLGAP
@app.get("/skill-gap/{student_id}")
def skill_gap(student_id: int):
    db = sql()
    cur = db.cursor(dictionary=True)
    cur.execute("SELECT Skills FROM new_account WHERE id=%s", (student_id,))
    student = cur.fetchone()
    if not student:
        return {"error": "Student not found"}
    student_skills = [s.strip().lower() for s in student["Skills"].split(",")]
    cur.execute(
        "SELECT job_title, required_skills FROM career_recommendations WHERE student_id=%s",
        (student_id,)
    )
    jobs = cur.fetchall()
    if not jobs:
        return {
            "student_id": student_id,
            "status": "pending",
            "message": "Career recommendation not generated yet"
        }
    result = []
    for job in jobs:
        job_name = job["job_title"]
        job_skills = [s.strip().lower() for s in job["required_skills"].split(",")]
        matching = [s for s in job_skills if s in student_skills]
        missing = [s for s in job_skills if s not in student_skills]
        match_percent = int((len(matching) / len(job_skills)) * 100)
        learning_plan = []
        for index, skill in enumerate(missing, start=1):
            learning_plan.append({
                "step": index,
                "skill": skill,
                "how_to_learn": f"Start with basics of {skill}, then practice projects",
                "resources": f"YouTube / Docs / Practice platforms for {skill}",
                "duration": "2-4 weeks"
            })
        result.append({
            "job": job_name,
            "match_percentage": match_percent,
            "progress": f"{len(matching)}/{len(job_skills)} skills",
            "matching_skills": matching,
            "missing_skills": missing,
            "learning_plan": learning_plan
        })
    db.close()
    return {
        "student_id": student_id,
        "data": result
    }

@app.get("/get-student/{email}")
def get_student(email: str):
    db = sql()
    cur = db.cursor(dictionary=True)
    cur.execute("SELECT id FROM new_account WHERE Email=%s", (email,))
    user = cur.fetchone()
    db.close()
    if user:
        return {"student_id": user["id"]}
    else:
        return {"error": "User not found"}

@app.get("/assessment-status/{email}")
def assessment_status(email: str):
    db = sql()
    cur = db.cursor(dictionary=True)

    # Get student id
    cur.execute("SELECT id FROM new_account WHERE Email=%s", (email,))
    user = cur.fetchone()

    if not user:
        db.close()
        return {"status": "not_found"}

    student_id = user["id"]

    # Check answers
    cur.execute(
        "SELECT COUNT(*) as count FROM student_answers WHERE student_id=%s",
        (student_id,)
    )
    result = cur.fetchone()

    db.close()

    if result["count"] > 0:
        return {"status": "completed"}
    else:
        return {"status": "pending"}

@app.post("/analyze-resume")
async def analyze_resume(file: UploadFile = File(...)):
    if not file.filename.endswith(".pdf"):
        return {"error": "Please upload a PDF file for analysis"}
        
    try:
        contents = await file.read()
        reader = PyPDF2.PdfReader(io.BytesIO(contents))
        text = ""
        for page in reader.pages:
            text += page.extract_text() or ""
            
        if not text.strip():
            return {"error": "Could not extract readable text from the PDF"}
            
        prompt = f"""
Analyze the following resume and provide a resume score out of 100 based on clarity, skills, experience, and formatting. Also, list 3 strengths and 3 areas of improvement.

Resume Text:
{text}

Return ONLY JSON in this format:
{{
    "score": 85,
    "strengths": ["Clear formatting", "Strong skills section"],
    "improvements": ["Lacks measurable achievements", "Add more keywords"]
}}
Return only JSON. No explanation.
"""
        response = requests.post(
            "http://localhost:11434/api/generate",
            json={
                "model": "gemma3:1b",
                "prompt": prompt,
                "stream": False
            },
            timeout=120
        )
        ai_text = response.json().get("response", "")
        # Extract JSON using regex
        match_json = re.search(r'\{.*\}', ai_text, re.DOTALL)
        if match_json:
            ai_result = json.loads(match_json.group())
        else:
            ai_result = {"error": "Could not parse AI response"}
            
        return {"analysis": ai_result}
    except Exception as e:
        return {"error": str(e)}