-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 19, 2026 at 11:28 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `career_guide`
--

-- --------------------------------------------------------

--
-- Table structure for table `career_recommendations`
--

CREATE TABLE `career_recommendations` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `job_title` varchar(255) DEFAULT NULL,
  `match_percentage` int(11) DEFAULT NULL,
  `required_skills` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `career_recommendations`
--

INSERT INTO `career_recommendations` (`id`, `student_id`, `job_title`, `match_percentage`, `required_skills`, `created_at`) VALUES
(1, 1, 'Web Developer', 92, 'HTML/CSS, JavaScript, React, Node.js, Git, Problem Solving', '2026-03-18 10:10:01'),
(2, 1, 'Data Scientist', 85, 'Python, Machine Learning, Statistics, SQL, Data Visualization', '2026-03-18 10:10:01'),
(3, 1, 'Full Stack Developer', 80, 'JavaScript, HTML/CSS, React, Node.js, Problem Solving', '2026-03-18 10:10:01'),
(7, 2, 'Backend Developer', 92, 'Python, Mysql', '2026-03-18 10:26:48'),
(8, 2, 'Data Scientist', 85, 'Python, Machine Learning, Statistics, SQL, Data Visualization', '2026-03-18 10:26:48'),
(9, 2, 'Software Developer', 80, 'JavaScript, React, Node.js, Git, Problem Solving', '2026-03-18 10:26:48');

-- --------------------------------------------------------

--
-- Table structure for table `new_account`
--

CREATE TABLE `new_account` (
  `Id` int(10) NOT NULL,
  `Full_Name` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Degree` varchar(100) NOT NULL,
  `Skills` varchar(100) NOT NULL,
  `Interests` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `new_account`
--

INSERT INTO `new_account` (`Id`, `Full_Name`, `Email`, `Password`, `Degree`, `Skills`, `Interests`) VALUES
(1, 'subash', 'subashbabu@gmail.com', 'babu12354', 'B.Com', 'Python,Java', 'WebDesigner'),
(2, 'Giri', 'giriravi@gmail.com', 'giri1234', 'B.Sc', 'Python,Mysql', 'Backend Developer'),
(3, 'madesh', 'madeshluffy@gmail.com', 'mad12345', 'B.CA ', 'Python,Mysql,ML', 'Backend Developer'),
(5, 'kani', 'kanish@gmail.com', 'kani1234', 'B.CA', 'githup,java', 'ui,ux');

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `id` int(11) NOT NULL,
  `question_id` int(11) DEFAULT NULL,
  `option` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`id`, `question_id`, `option`) VALUES
(1, 1, 'Remote/Home office'),
(2, 1, 'Traditional office setting'),
(3, 1, 'Hybrid model'),
(4, 1, 'Outdoor/Field work'),
(5, 2, 'Solving technical problems'),
(6, 2, 'Designing creative things'),
(7, 2, 'Analyzing data'),
(8, 2, 'Helping people'),
(9, 3, 'High salary'),
(10, 3, 'Work-life balance'),
(11, 3, 'Learning new skills'),
(12, 3, 'Job stability'),
(13, 4, 'Programming'),
(14, 4, 'Communication'),
(15, 4, 'Leadership'),
(16, 4, 'Creativity'),
(17, 5, 'Working with computers'),
(18, 5, 'Managing teams'),
(19, 5, 'Research and analysis'),
(20, 5, 'Creative design'),
(21, 6, 'Mathematics'),
(22, 6, 'Business'),
(23, 6, 'Psychology'),
(24, 6, 'Arts'),
(25, 7, 'Startup'),
(26, 7, 'Large corporate'),
(27, 7, 'Government job'),
(28, 7, 'Freelance'),
(29, 8, 'Logical thinking'),
(30, 8, 'Discussion with others'),
(31, 8, 'Research and reading'),
(32, 8, 'Trial and error'),
(33, 9, 'Independent work'),
(34, 9, 'Team collaboration'),
(35, 9, 'Leadership role'),
(36, 9, 'Flexible projects'),
(37, 10, 'Technology industry'),
(38, 10, 'Business sector'),
(39, 10, 'Healthcare'),
(40, 10, 'Creative industry');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `question` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `question`) VALUES
(1, 'What type of work environment do you prefer?'),
(2, 'Which activity do you enjoy the most?'),
(3, 'What motivates you the most in a career?'),
(4, 'Which skill describes you best?'),
(5, 'What type of tasks do you prefer?'),
(6, 'Which subject do you like the most?'),
(7, 'What type of company do you prefer?'),
(8, 'How do you prefer solving problems?'),
(9, 'Which work style suits you?'),
(10, 'Where do you see yourself working?');

-- --------------------------------------------------------

--
-- Table structure for table `student_answers`
--

CREATE TABLE `student_answers` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `question_id` int(11) DEFAULT NULL,
  `selected_option` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_answers`
--

INSERT INTO `student_answers` (`id`, `student_id`, `question_id`, `selected_option`) VALUES
(1, 1, 1, 'Remote/Home office'),
(2, 1, 2, 'Solving technical problems'),
(3, 1, 3, 'Learning new skills'),
(4, 1, 4, 'Programming'),
(5, 1, 5, 'Working with computers'),
(6, 1, 6, 'Mathematics'),
(7, 1, 7, 'Startup'),
(8, 1, 8, 'Logical thinking'),
(9, 1, 9, 'Independent work'),
(10, 1, 10, 'Technology industry'),
(21, 2, 1, 'Traditional office setting'),
(22, 2, 2, 'Helping people'),
(23, 2, 3, 'Job stability'),
(24, 2, 4, 'Leadership'),
(25, 2, 5, 'Managing teams'),
(26, 2, 6, 'Business'),
(27, 2, 7, 'Large corporate'),
(28, 2, 8, 'Discussion with others'),
(29, 2, 9, 'Team collaboration'),
(30, 2, 10, 'Business sector'),
(31, 3, 1, 'Hybrid model'),
(32, 3, 2, 'Designing creative things'),
(33, 3, 3, 'Work-life balance'),
(34, 3, 4, 'Creativity'),
(35, 3, 5, 'Creative design'),
(36, 3, 6, 'Arts'),
(37, 3, 7, 'Freelance'),
(38, 3, 8, 'Trial and error'),
(39, 3, 9, 'Flexible projects'),
(40, 3, 10, 'Creative industry');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `career_recommendations`
--
ALTER TABLE `career_recommendations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_student_rank` (`student_id`,`job_title`);

--
-- Indexes for table `new_account`
--
ALTER TABLE `new_account`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`id`),
  ADD KEY `question_id` (`question_id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_answers`
--
ALTER TABLE `student_answers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `career_recommendations`
--
ALTER TABLE `career_recommendations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `new_account`
--
ALTER TABLE `new_account`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `options`
--
ALTER TABLE `options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `student_answers`
--
ALTER TABLE `student_answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `options`
--
ALTER TABLE `options`
  ADD CONSTRAINT `options_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
